"""TRUTH CROWN - 'In this world' 9:16 Roblox Short.

In this world, a golden crown appears on your head every time you tell the truth.
A bully frames the narrator's little sister; one shouted truth saves her.

Build:   python scripts/make_short.py stories/truth_crown.py --stills
Render:  python scripts/make_short.py stories/truth_crown.py --skip-tts --render
"""
from shorts.scene import HALF, OFF, close_up, cover, face, hold, kf, medium, shot, wide  # noqa: F401

TITLE = "TRUTH CROWN"

# 1. SCRIPT ------------------------------------------------------------------
BEATS = [
    {"id": "b1", "text": "In this world, a golden crown appears on your head every time you tell the truth.", "pause": 0.08},
    {"id": "b2", "text": "Tell one lie, and it vanishes before anyone can see it.", "pause": 0.08},
    {"id": "b3", "text": "Honest kids wear theirs all day, like shiny little badges.", "pause": 0.07},
    {"id": "b4", "text": "The bully never has one. His head is always bare.", "pause": 0.08},
    {"id": "b5", "text": "I wore mine everywhere, so they called me Crown Boy.", "pause": 0.08},
    {"id": "b6", "text": "Then the school trophy shattered right outside the principal's office.", "pause": 0.08},
    {"id": "b7", "text": "The bully pointed at my little sister and swore she did it.", "pause": 0.08},
    {"id": "b8", "text": "She said she didn't, and her little crown lit up.", "pause": 0.09},
    {"id": "b9", "text": "The principal said one word from me would settle it.", "pause": 0.08},
    {"id": "b10", "text": "The bully leaned close and told me to lie for him.", "pause": 0.08},
    {"id": "b11", "text": "I looked at my sister, took a breath, and shouted...", "pause": 0.16},
    {"id": "w1", "text": "IT!", "voice": "am_michael", "shout": True, "pause": 0.12},
    {"id": "w2", "text": "WAS!", "voice": "am_michael", "shout": True, "pause": 0.12},
    {"id": "w3", "text": "HIM!", "voice": "am_michael", "shout": True, "pause": 0.20},
    {"id": "b12", "text": "My crown blazed, and the whole hallway finally knew the truth.", "pause": 0.10},
    {"id": "b13", "text": "But last night, I told Mom I wasn't scared, and my crown stayed on.", "pause": 0.30},
]

# 2. MUSIC + SFX ---------------------------------------------------------------
MUSIC = {
    "file": "music/fallen-down.mp3",
    "under_voice": 0.022,
    "gaps": 0.05,
    "dropouts": [("b11+0.2", "w3.end")],
}

SFX = [
    ("b1", "whoosh"),
    ("b1+1.2", "sparkle"),
    ("b2+0.6", "pop", {"f": 620}),
    ("b3+0.5", "sparkle"),
    ("b4+0.8", "bell_low"),
    ("b5+0.6", "pop", {"f": 740}),
    ("b6", "thud"),
    ("b7+0.8", "laugh"),
    ("b8+0.6", "sparkle"),
    ("b9", "ding_dong"),
    ("b10+1.2", "riser", {"dur": 1.8}),
    ("w1", "impact"),
    ("w2", "impact"),
    ("w3", "impact"),
    ("w3+0.18", "reveal"),
    ("b12+0.5", "whoosh"),
    ("b13+1.8", "twist"),
]

# 3. CAST ---------------------------------------------------------------------
HERO = {
    "extends": "kid_boy",
    "skin": "light",
    "hair": {"style": "messyFringe", "color": "darkBrown"},
    "top": {"style": "hoodie", "color": "royal", "secondary": "white"},
    "bottom": {"style": "jeans", "color": "denim"},
    "shoes": {"color": "white", "sole": "white"},
    "accessories": ["crown"],
}
CAST = {
    "hero": HERO,
    "sister": {"extends": "kid_girl", "hair": {"style": "pigtails", "color": "auburn"},
               "top": {"style": "dress", "color": "pink", "secondary": "white"},
               "accessories": ["crown"], "scale": 0.8},
    "bully": {"extends": "bully", "accessories": []},   # bare head: he never tells the truth
    "honest_kid": {"extends": "schoolboy", "hair": {"style": "spikyAnime", "color": "black"},
                   "accessories": ["crown"]},
    "honest_girl": {"extends": "schoolgirl", "hair": {"style": "ponytail", "color": "blonde"},
                    "accessories": ["crown"]},
    "principal": {"extends": "principal", "accessories": ["crown"]},
    "mom": {"extends": "real_mom", "hair": {"style": "bun", "color": "brown"},
            "accessories": ["crown"]},
}


# 4. SCENES --------------------------------------------------------------------
def scenes(T):
    B, E, END = T.B, T.E, T.END

    S_STREET = B["b2"] - 1
    S_SCHOOL = B["b5"] - 1
    S_HALL = B["b6"] - 1
    S_HOME = B["b13"] - 1

    HERO_P = [0, 0, 1.5]
    SIS_P = [5.2, 0, 2.2]
    BULLY_P = [-5.4, 0, 1.5]
    PRIN_P = [0, 0, -5.5]

    SHOUT0, SHOUT1 = B["w1"] - 6, E["w3"] + 6
    HOME_HERO, HOME_MOM = [-4.5, 0, 0.5], [4.0, 0, 0.5]

    out = []

    # A. TOWN OVERVIEW - the rule ------------------------------------------------
    hook_mid = S_STREET // 2
    out.append({
        "id": "scene-hook",
        "location": "town_overview",
        "startFrame": 0,
        "endFrame": S_STREET,
        "cameraShots": [
            shot(0, hook_mid, [-10, 62, 74], [-8, 60, 70], [8, 0, -6], [7, 0, -6], 55),
            shot(hook_mid, S_STREET, [-8, 60, 70], [-5, 56, 66], [7, 0, -6], [5, 1, -7], 55),
        ],
        "characters": {},
    })

    # B. STREET - crowns everywhere except on the bully ---------------------------
    out.append({
        "id": "scene-street",
        "location": "street",
        "startFrame": S_STREET,
        "endFrame": S_SCHOOL,
        "cameraShots": [
            shot(S_STREET, B["b3"] - 1, [-5.5, 5.6, 13], [-5.3, 5.4, 11.5], [-5.5, 4.3, 0.5], [-5.5, 4.3, 0.5], 47),
            shot(B["b3"] - 1, B["b4"] - 1, [0, 5.8, 13.5], [0.3, 5.5, 12], [0, 4.3, 0.5], [0, 4.3, 0.5], 50),
            shot(B["b4"] - 1, S_SCHOOL, [5.6, 5.6, 13], [5.4, 5.4, 11.5], [5.6, 4.3, 0.5], [5.6, 4.3, 0.5], 47),
        ],
        "characters": {
            "honest_kid": hold(S_STREET, S_SCHOOL, [-5.5, 0, 0.5], 0.1, "idle", "smile"),
            "honest_girl": hold(S_STREET, S_SCHOOL, [0, 0, 0.5], -0.1, "wave", "laugh"),
            "bully": hold(S_STREET, S_SCHOOL, [5.6, 0, 0.5], -0.2, "idle", "angry"),
        },
    })

    # C. SCHOOL EXTERIOR - "Crown Boy" --------------------------------------------
    out.append({
        "id": "scene-school",
        "location": "school_exterior",
        "schoolName": "CROWNVILLE SCHOOL",
        "startFrame": S_SCHOOL,
        "endFrame": S_HALL,
        "cameraShots": [
            medium(S_SCHOOL, (S_SCHOOL + S_HALL) // 2, [0, 0, 2.3]),
            close_up((S_SCHOOL + S_HALL) // 2, S_HALL, HERO_P),
        ],
        "characters": {
            "hero": hold(S_SCHOOL, S_HALL, [-2.6, 0, 3], 0, "idle", "smile"),
            "bully": hold(S_SCHOOL, S_HALL, [2.8, 0, 3], 0, "point", "laugh"),
            "honest_kid": hold(S_SCHOOL, S_HALL, [7.6, 0, 1], -0.4, "idle", "smile"),
        },
    })

    # D. HALLWAY - framed sister, shouted truth ------------------------------------
    out.append({
        "id": "scene-hallway",
        "location": "hallway",
        "startFrame": S_HALL,
        "endFrame": S_HOME,
        "cameraShots": [
            wide(S_HALL, B["b7"] - 1, [0, 0, 0.5]),
            medium(B["b7"] - 1, B["b8"] - 1, [1.5, 0, 2]),
            close_up(B["b8"] - 1, B["b9"] - 1, SIS_P, scale=0.8),
            medium(B["b9"] - 1, B["b10"] - 1, [0, 0, -1.5], dist=14),
            medium(B["b10"] - 1, B["b11"] - 1, [-2.6, 0, 1.5], dist=11),
            close_up(B["b11"] - 1, SHOUT0, HERO_P, shake=0.04),
            shot(SHOUT0, SHOUT1, [0, 7.4, 20.5], [0, 7.0, 17.5], [0, 4.8, 0], [0, 4.8, 0], 58, 0.08),
            medium(SHOUT1, S_HOME, [1, 0, 1.5], dist=13),
        ],
        "characters": {
            "hero": [
                kf(S_HALL, HERO_P, 0, "idle", "shocked"),
                kf(B["b7"] - 1, HERO_P, 0, "idle", "deadpan"),
                kf(B["b8"] - 1, HERO_P, 0.5, "point", "smile"),
                kf(B["b9"] - 1, HERO_P, 0, "idle", "deadpan"),
                kf(B["b10"] - 1, HERO_P, -0.3, "idle", "shocked"),
                kf(B["b11"] - 1, HERO_P, 0, "idle", "deadpan"),
                kf(SHOUT0, HERO_P, 0, "point", "angry"),
                kf(SHOUT1, HERO_P, 0, "idle", "cool"),
                kf(S_HOME, HERO_P, 0, "idle", "cool"),
            ],
            "sister": [
                kf(S_HALL, SIS_P, -0.5, "idle", "shocked"),
                kf(B["b7"] - 1, SIS_P, -0.5, "idle", "panic"),
                kf(B["b8"] - 1, SIS_P, -0.4, "wave", "smile"),
                kf(B["b10"] - 1, SIS_P, -0.4, "idle", "panic"),
                kf(SHOUT0, SIS_P, -0.4, "idle", "smile"),
                kf(S_HOME, SIS_P, -0.4, "idle", "smile"),
            ],
            "bully": [
                kf(S_HALL, BULLY_P, HALF, "idle", "angry"),
                kf(B["b7"] - 1, BULLY_P, HALF, "point", "laugh"),
                kf(B["b8"] - 1, BULLY_P, HALF, "idle", "angry"),
                kf(B["b10"] - 1, BULLY_P, HALF, "idle", "angry"),
                kf(B["b11"] - 1, BULLY_P, HALF, "point", "laugh"),
                kf(SHOUT0, BULLY_P, HALF, "idle", "panic"),
                kf(S_HOME, BULLY_P, HALF, "idle", "panic"),
            ],
            "principal": [
                kf(S_HALL, PRIN_P, 0, "idle", "deadpan", "clipboard"),
                kf(B["b7"] - 1, PRIN_P, 0, "idle", "angry", "clipboard"),
                kf(B["b9"] - 1, PRIN_P, 0, "point", "deadpan", "clipboard"),
                kf(B["b10"] - 1, PRIN_P, 0, "idle", "deadpan", "clipboard"),
                kf(SHOUT0, PRIN_P, 0, "idle", "shocked", "clipboard"),
                kf(SHOUT1, PRIN_P, 0, "idle", "smile", "clipboard"),
                kf(S_HOME, PRIN_P, 0, "idle", "smile", "clipboard"),
            ],
        },
    })

    # E. LIVING ROOM, NIGHT - the crown that stayed on ------------------------------
    twist_mid = (S_HOME + END) // 2
    out.append({
        "id": "scene-home",
        "location": "living_room",
        "variant": "yellow",
        "isNight": True,
        "startFrame": S_HOME,
        "endFrame": END,
        "cameraShots": [
            medium(S_HOME, twist_mid, [-0.2, 0, 0.5], dist=13),
            close_up(twist_mid, END, HOME_HERO),
        ],
        "characters": {
            "hero": [
                kf(S_HOME, HOME_HERO, 0.5, "idle", "smile"),
                kf(END - 10, HOME_HERO, 0.5, "idle", "cool"),
                kf(END, HOME_HERO, 0.5, "idle", "shocked"),
            ],
            "mom": hold(S_HOME, END, HOME_MOM, -0.6, "wave", "smile"),
        },
    })

    return out
