"""PROMISE HALO - 9:16 Roblox Short ("In this world...").

Build:   python scripts/make_short.py stories/promise_halo.py --stills
Render:  python scripts/make_short.py stories/promise_halo.py --skip-tts --render
"""
from shorts.scene import (HALF, OFF, close_up, cover, face, hold, kf, medium,  # noqa: F401
                          shot, split_shots, wide)

TITLE = "BROKEN PROMISES TURN YOUR HALO RED"

# 1. SCRIPT ------------------------------------------------------------------
BEATS = [
    {"id": "b1", "text": "In this world, every promise you make floats above your head as a glowing halo.", "pause": 0.08},
    {"id": "b2", "text": "Keep your word and it burns gold. Break it, and it turns blood red.", "pause": 0.08},
    {"id": "b3", "text": "The richest kid in town shines so bright that nobody can look straight at him.", "pause": 0.07},
    {"id": "b4", "text": "I only had one little halo, but I guarded it with my whole life.", "pause": 0.07},
    {"id": "b5", "text": "Then my little sister made a promise to the school bully.", "pause": 0.08},
    {"id": "b6", "text": "I begged her not to go, but she said a promise is a promise.", "pause": 0.08},
    {"id": "b7", "text": "That night, he cornered her at the slide tower in the empty park.", "pause": 0.08},
    {"id": "b8", "text": "He pointed at her halo, and the gold started to flicker red.", "pause": 0.09},
    {"id": "b9", "text": "Then he shoved her into the tower and sprinted into the dark.", "pause": 0.08},
    {"id": "b10", "text": "I had promised Mom I would never break a promise. Not once.", "pause": 0.08},
    {"id": "b11", "text": "But my sister was crying, so I stepped forward and took a breath.", "pause": 0.09},
    {"id": "b12", "text": "Everyone froze as I looked that bully in the eye and shouted...", "pause": 0.14},
    {"id": "w1", "text": "BREAK!", "voice": "am_michael", "shout": True, "pause": 0.12},
    {"id": "w2", "text": "MY!", "voice": "am_michael", "shout": True, "pause": 0.12},
    {"id": "w3", "text": "PROMISE!", "voice": "am_michael", "shout": True, "pause": 0.18},
    {"id": "b13", "text": "My golden halo cracked and turned blood red, and the bully froze in terror.", "pause": 0.08},
    {"id": "b14", "text": "But last night, mine turned gold again. His never came back.", "pause": 0.30},
]

# 2. MUSIC + SFX ---------------------------------------------------------------
MUSIC = {
    "file": "music/fallen-down.mp3",
    "under_voice": 0.022,
    "gaps": 0.05,
    "dropouts": [("b12+0.3", "w3.end")],
}

SFX = [
    ("b1", "whoosh"),
    ("b1+0.8", "sparkle"),
    ("b2+0.5", "pop", {"f": 720}),
    ("b2+1.7", "bell_low"),
    ("b3+1.0", "sparkle"),
    ("b4+1.2", "pop", {"f": 560}),
    ("b5+1.6", "pop", {"f": 640}),
    ("b6+1.4", "sad"),
    ("b7", "whoosh"),
    ("b7+1.7", "bell_low"),
    ("b8+1.1", "riser", {"dur": 1.6}),
    ("b8+2.2", "sparkle"),
    ("b9+0.5", "thud"),
    ("b9+1.5", "sad"),
    ("b10+1.2", "bell_low"),
    ("b11+1.0", "sad"),
    ("b12", "riser", {"dur": 2.0}),
    ("w1", "impact"),
    ("w2", "impact"),
    ("w3", "reveal"),
    ("b13+0.5", "thud"),
    ("b13+1.4", "whoosh"),
    ("b14+1.6", "twist"),
]

# 3. CAST ----------------------------------------------------------------------
CAST = {
    "hero": {
        "extends": "kid_boy",
        "skin": "light",
        "hair": {"style": "messyFringe", "color": "brown"},
        "top": {"style": "hoodie", "color": "royal", "secondary": "white"},
        "bottom": {"style": "jeans", "color": "denim"},
        "shoes": {"style": "sneakers", "color": "white", "sole": "white"},
    },
    "sister": {
        "extends": "kid_girl",
        "skin": "fair",
        "hair": {"style": "pigtails", "color": "auburn"},
        "top": {"style": "dress", "color": "pink", "secondary": "white"},
        "scale": 0.8,
    },
    "rich_kid": {
        "extends": "cool_kid",
        "hair": {"style": "fluffySwept", "color": "goldenBlonde"},
        "top": {"style": "jacket", "color": "purple", "secondary": "yellow"},
        "accessories": ["sunglasses"],
    },
    "liar_kid": {
        "extends": "schoolboy",
        "hair": {"style": "spikyAnime", "color": "black"},
        "top": {"style": "sweater", "color": "gray", "secondary": "white"},
    },
    "bully": "bully",
    "mom": {"extends": "real_mom", "hair": {"style": "bun", "color": "darkBrown"}},
}


# 4. SCENES --------------------------------------------------------------------
def scenes(T):
    B, END = T.B, T.END

    S_B = B["b2"] - 1     # street: gold vs red
    S_C = B["b3"] - 1     # shop: the shining rich kid, then my one halo
    S_D = B["b5"] - 1     # school: sister makes the promise
    S_E = B["b6"] - 1     # living room: I beg her not to go
    S_F = B["b7"] - 1     # playground, night: the whole crisis
    S_G = B["b14"] - 1    # living room, night: the twist

    RICH_P, LIAR_P = [-4.5, 0, 0.5], [1.0, 0, 0.5]
    SHOP_RICH_P, SHOP_HERO_P = [-3.0, 0, 0.5], [2.0, 0, 0.5]
    SCH_SIS_P, SCH_BULLY_P, SCH_HERO_P = [0, 0, 0], [4.5, 0, 0], [-4.5, 0, 0]
    HOME_HERO_P, HOME_SIS_P = [-3.0, 0, 1.0], [2.0, 0, 1.0]
    SIS_P, BULLY_P, HERO_P = [-5.5, 0, 1.0], [0, 0, 2.0], [5.5, 0, 2.5]
    TOWER_P = [-5.5, 0, -1.5]
    FROZEN = B["b13"]

    return [
        # A. TOWN OVERVIEW ------------------------------------------------------
        {
            "id": "scene-hook",
            "location": "town_overview",
            "startFrame": 0,
            "endFrame": S_B,
            "cameraShots": split_shots(0, S_B, [
                lambda a, b: shot(a, b, [-10, 62, 74], [-7, 56, 68], [8, 0, -6], [6, 2, -8], 55),
                lambda a, b: shot(a, b, [-6, 50, 62], [-3, 44, 55], [6, 2, -8], [4, 3, -10], 53),
            ]),
            "characters": {},
        },

        # B. STREET - gold and red halos ----------------------------------------
        {
            "id": "scene-rule",
            "location": "street",
            "startFrame": S_B,
            "endFrame": S_C,
            "cameraShots": split_shots(S_B, S_C, [
                lambda a, b: medium(a, b, [-1.75, 0, 0.5], dist=12, height=6.6, fov=52),
                lambda a, b: medium(a, b, [-1.75, 0, 0.5], dist=10, height=6.2, fov=48),
            ]),
            "characters": {
                "rich_kid": hold(S_B, S_C, RICH_P, 0.15, "idle", "cool", "halo_gold"),
                "liar_kid": hold(S_B, S_C, LIAR_P, -0.3, "idle", "deadpan", "halo_red"),
            },
        },

        # C. SHOP - the dazzling rich kid, then my own small halo -----------------
        {
            "id": "shop",
            "location": "shop",
            "startFrame": S_C,
            "endFrame": S_D,
            "cameraShots": cover(S_C, S_D, [
                lambda a, b: wide(a, b, [-0.5, 0, 0.5], dist=19, fov=57),
                lambda a, b: close_up(a, b, SHOP_RICH_P, fov=46),
                lambda a, b: medium(a, b, SHOP_HERO_P, dist=10, height=5.8, fov=48),
            ]),
            "characters": {
                "rich_kid": hold(S_C, S_D, SHOP_RICH_P, 0.1, "celebrate", "laugh", "halo_gold"),
                "hero": hold(S_C, S_D, SHOP_HERO_P, -0.2, "idle", "smile", "halo_gold"),
            },
        },

        # D. SCHOOL - the sister makes the fatal promise --------------------------
        {
            "id": "school-promise",
            "location": "school_exterior",
            "schoolName": "HALO SCHOOL",
            "startFrame": S_D,
            "endFrame": S_E,
            "cameraShots": split_shots(S_D, S_E, [
                lambda a, b: wide(a, b, [0, 0, 1], dist=21, fov=58),
                lambda a, b: medium(a, b, [2.25, 0, 0], dist=11, height=6.2, fov=51),
            ]),
            "characters": {
                "sister": hold(S_D, S_E, SCH_SIS_P, face(SCH_SIS_P, SCH_BULLY_P), "wave", "smile", "halo_gold"),
                "bully": hold(S_D, S_E, SCH_BULLY_P, face(SCH_BULLY_P, SCH_SIS_P), "point", "laugh", "halo_red"),
                "hero": hold(S_D, S_E, SCH_HERO_P, face(SCH_HERO_P, SCH_SIS_P), "idle", "shocked", "halo_gold"),
            },
        },

        # E. LIVING ROOM - I warn her -------------------------------------------
        {
            "id": "warning",
            "location": "living_room",
            "variant": "blue",
            "startFrame": S_E,
            "endFrame": S_F,
            "cameraShots": [medium(S_E, S_F, [0, 0, 1], dist=14, height=6.0, fov=54)],
            "characters": {
                "hero": hold(S_E, S_F, HOME_HERO_P, face(HOME_HERO_P, HOME_SIS_P), "point", "panic", "halo_gold"),
                "sister": hold(S_E, S_F, HOME_SIS_P, face(HOME_SIS_P, HOME_HERO_P), "idle", "deadpan", "halo_gold"),
            },
        },

        # F. PLAYGROUND - cornered, shoved, and the shouted choice ----------------
        {
            "id": "playground-crisis",
            "location": "playground",
            "isNight": True,
            "startFrame": S_F,
            "endFrame": S_G,
            "cameraShots": [
                shot(S_F, B["b8"], [0, 8.2, 21], [-1, 7.4, 18], [0, 4.4, -2], [-1, 4.2, -2], 57),
                close_up(B["b8"], B["b9"], SIS_P, scale=0.8, dist=8.0, fov=45),
                shot(B["b9"], B["b10"], [-2.5, 7.0, 16], [-2.0, 6.4, 13.5], [-3.5, 4.4, -2], [-4.0, 4.4, -2], 51),
                close_up(B["b10"], B["b11"], HERO_P, dist=9.0, fov=46),
                shot(B["b11"], B["b12"], [2.5, 7.6, 18], [2.0, 6.6, 15], [2.5, 4.4, 1.5], [3, 4.4, 2], 55),
                shot(B["b12"], FROZEN, [2.5, 5.8, 12.5], [2.0, 6.2, 15.5], [2.5, 4.4, 2.5], [1.5, 4.6, 2], 49, 0.07),
                shot(FROZEN, S_G, [1.5, 7.0, 17], [0.5, 6.2, 14], [1, 4.4, 1], [0, 4.4, 1], 53, 0.05),
            ],
            "characters": {
                "sister": [
                    kf(S_F, SIS_P, face(SIS_P, BULLY_P), "idle", "panic", "halo_gold"),
                    kf(B["b8"], SIS_P, face(SIS_P, BULLY_P), "idle", "panic", "halo_gold"),
                    kf(B["b8"] + 12, SIS_P, face(SIS_P, BULLY_P), "idle", "shocked", "halo_red"),
                    kf(B["b9"], SIS_P, face(SIS_P, BULLY_P), "idle", "panic", "halo_red"),
                    kf(B["b9"] + 16, TOWER_P, 0.4, "knocked", "panic", "halo_red"),
                    kf(FROZEN, TOWER_P, 0.4, "knocked", "panic", "halo_red"),
                    kf(S_G, TOWER_P, 0.4, "knocked", "panic", "halo_red"),
                ],
                "bully": [
                    kf(S_F, BULLY_P, face(BULLY_P, SIS_P), "point", "laugh", "halo_red"),
                    kf(B["b9"], BULLY_P, face(BULLY_P, SIS_P), "sprint", "laugh", "halo_red"),
                    kf(B["b9"] + 30, [10, 0, 5], HALF, "sprint", "laugh", "halo_red"),
                    kf(B["b10"], [10, 0, 5], HALF, "idle", "cool", "halo_red"),
                    kf(FROZEN, [-3.5, 0, 4.5], face([-3.5, 0, 4.5], HERO_P), "idle", "shocked", "halo_red"),
                    kf(S_G, [-3.5, 0, 4.5], face([-3.5, 0, 4.5], HERO_P), "idle", "panic", "halo_red"),
                ],
                "hero": [
                    kf(S_F, [11, 0, 6], -0.8, "idle", "panic", "halo_gold"),
                    kf(B["b10"], [11, 0, 6], -0.8, "idle", "panic", "halo_gold"),
                    kf(B["b10"] + 40, [8.5, 0, 5], -0.6, "walk", "panic", "halo_gold"),
                    kf(B["b11"], HERO_P, 0.0, "walk", "angry", "halo_gold"),
                    kf(B["b12"], HERO_P, 0.0, "idle", "angry", "halo_gold"),
                    kf(B["w1"], HERO_P, 0.0, "point", "angry", "halo_gold"),
                    kf(B["w2"], HERO_P, 0.0, "point", "angry", "halo_red"),
                    kf(FROZEN, HERO_P, 0.0, "point", "shocked", "halo_red"),
                    kf(S_G, HERO_P, 0.0, "idle", "panic", "halo_red"),
                ],
            },
        },

        # G. LIVING ROOM - the halo comes back -----------------------------------
        {
            "id": "twist",
            "location": "living_room",
            "variant": "blue",
            "isNight": True,
            "startFrame": S_G,
            "endFrame": END,
            "cameraShots": cover(S_G, END, [
                lambda a, b: medium(a, b, [0, 0, 1], dist=13, height=5.6, fov=52),
                lambda a, b: close_up(a, b, HOME_HERO_P, dist=7.5, fov=43),
            ]),
            "characters": {
                "hero": [
                    kf(S_G, HOME_HERO_P, 0.2, "idle", "deadpan", "halo_red"),
                    kf(B["b14"] + 42, HOME_HERO_P, 0.2, "idle", "shocked", "halo_gold"),
                    kf(END, HOME_HERO_P, 0.2, "idle", "shocked", "halo_gold"),
                ],
                "mom": hold(S_G, END, [2.0, 0, 1.0], -0.7, "idle", "smile", "halo_gold"),
            },
        },
    ]
