import { Config } from '@remotion/cli/config';
Config.setChromiumOpenGlRenderer('swiftshader');
Config.overrideWebpackConfig((c) => c);
